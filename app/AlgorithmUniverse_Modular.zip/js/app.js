
                import { treeData } from './data-tree.js';
                // app initialization logic
            