export const treeData = {
    "id": "ROOT",
    "name": "CS Mastery",
    "children": [
        {
            "name": "Complexity",
            "children": [
                {
                    "name": "Time Complexity"
                },
                {
                    "name": "Space Complexity"
                },
                {
                    "name": "Big O"
                }
            ]
        },
        {
            "name": "Data Structures",
            "children": [
                {
                    "name": "Linear",
                    "children": [
                        {
                            "name": "Arrays"
                        },
                        {
                            "name": "Linked Lists"
                        },
                        {
                            "name": "Stacks"
                        }
                    ]
                },
                {
                    "name": "Non-Linear",
                    "children": [
                        {
                            "name": "Trees (BST, AVL, RB)"
                        },
                        {
                            "name": "Graphs"
                        },
                        {
                            "name": "Heaps"
                        }
                    ]
                }
            ]
        },
        {
            "name": "Algorithms",
            "children": [
                {
                    "name": "Two Pointers",
                    "children": [
                        {
                            "name": "Converging"
                        },
                        {
                            "name": "Sliding Window"
                        }
                    ]
                },
                {
                    "name": "Search",
                    "children": [
                        {
                            "name": "Binary Search"
                        },
                        {
                            "name": "KMP"
                        }
                    ]
                }
            ]
        }
    ]
};