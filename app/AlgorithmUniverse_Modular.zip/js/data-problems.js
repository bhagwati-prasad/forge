
                export const twoPointerProblems = { /* 120 problems here */ };
                export const searchProblems = { /* 120 problems here */ };
            