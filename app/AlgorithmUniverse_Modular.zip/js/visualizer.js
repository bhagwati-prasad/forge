
                export const Visualizer = {
                    renderGraph: (node) => { /* logic */ },
                    renderDirectory: (node) => { /* logic */ }
                };
            